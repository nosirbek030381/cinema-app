import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import LoginScreen from '../screens/login';
import SignUpScreen from '../screens/register';
import WelcomeScreen from '../screens/welcome';

const Stack = createNativeStackNavigator();

const GuestStack = () => {
	return (
		<Stack.Navigator>
			<Stack.Screen name='Welcome' component={WelcomeScreen} options={{ headerShown: false }} />
			<Stack.Screen name='Login' component={LoginScreen} options={{ headerShown: true }} />
			<Stack.Screen name='Register' component={SignUpScreen} options={{ headerShown: true }} />
		</Stack.Navigator>
	);
};

export default GuestStack;
