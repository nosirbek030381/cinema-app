// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
	apiKey: 'AIzaSyAv7-0I_ypSAedmuxuWb_LtBviBUqBqW3g',
	authDomain: 'loginfirebaseauth-67673.firebaseapp.com',
	projectId: 'loginfirebaseauth-67673',
	storageBucket: 'loginfirebaseauth-67673.appspot.com',
	messagingSenderId: '388511651131',
	appId: '1:388511651131:web:92b6c4f93fae9a021cd31e',
	measurementId: 'G-7EWW2ZCHBR',
};

// Initialize Firebase

firebase.initializeApp(firebaseConfig);
const app = initializeApp(firebaseConfig);
const authentication = getAuth(app);
export { authentication, firebase };
