# React nativeda baza bilan ishlash

```
npm install
```

```
npm start
```

## Hammasini o'rnatib ishlating baza firebase
