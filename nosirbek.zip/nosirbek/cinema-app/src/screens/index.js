export { default as Home } from './home';
export { default as Movie } from './movie';
