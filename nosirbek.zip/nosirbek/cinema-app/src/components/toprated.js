import React from 'react';
import { Text, View } from 'react-native';

export default function TopratedMovie() {
	return (
		<View>
			<Text>Toprated </Text>
		</View>
	);
}
