import AppNavigation from './src/navigations/app.navigation';
import './src/styles/global.css';

export default function App() {
	return <AppNavigation />;
}
