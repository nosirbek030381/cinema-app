# React nativeda cinema-app

Nodejs ni o'rnatish kerak <br />
https://nodejs.org/en/download

```
node -v
npm -v
```

# install expo

```
npm install --global expo-cli
```

# create first "my-app" application

```
expo init my-app
```

# open folder

```
cd my-app
```

# start expo development server

```
expo start
```

or

```
npm start
```
