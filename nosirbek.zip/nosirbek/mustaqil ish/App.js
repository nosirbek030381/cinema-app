import React from 'react';
import { SafeAreaView } from 'react-native';
import { WebView } from 'react-native-webview';

const MyWebView = () => {
	return (
		<SafeAreaView style={{ flex: 1, marginTop: 40 }}>
			<WebView
				source={{
					uri: 'https://reactnative.dev',
				}}
			/>
		</SafeAreaView>
	);
};

export default MyWebView;
